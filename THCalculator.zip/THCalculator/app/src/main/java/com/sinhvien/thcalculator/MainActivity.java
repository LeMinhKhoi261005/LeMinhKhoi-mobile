package com.sinhvien.thcalculator;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    EditText edit1,edit2,editKQ;
    TextView txt1,txt2,txtKQ;
    Button btnTong,btnHieu,btnTich,btnThuong;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        edit1 = findViewById(R.id.edit1);
        edit2 = findViewById(R.id.edit2);
        editKQ = findViewById(R.id.editKQ);

        txt1 = findViewById(R.id.txt1);
        txt2 = findViewById(R.id.txt2);
        txtKQ = findViewById(R.id.txtKQ);

        btnTong = findViewById(R.id.btnTong);
        btnHieu = findViewById(R.id.btnHieu);
        btnTich = findViewById(R.id.btnTich);
        btnThuong = findViewById(R.id.btnThuong);

        btnTong.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int a = Integer.parseInt("0" + edit1.getText());
                int b = Integer.parseInt("0" + edit2.getText());
                editKQ.setText("a + b = " + (a + b));
            }
        });
        btnHieu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int a = Integer.parseInt("0" + edit1.getText());
                int b = Integer.parseInt("0" + edit2.getText());
                editKQ.setText("a - b = " + (a - b));
            }
        });
        btnTich.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int a = Integer.parseInt("0" + edit1.getText());
                int b = Integer.parseInt("0" + edit2.getText());
                editKQ.setText("a * b = " + (a * b));
            }
        });
        btnThuong.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int a = Integer.parseInt("0" + edit1.getText());
                int b = Integer.parseInt("0" + edit2.getText());
                if (b == 0){
                    editKQ.setText("B phải khác 0");
                }
                else {
                    editKQ.setText("a / b = " + (a / b));
                }
            }
        });
    }
}