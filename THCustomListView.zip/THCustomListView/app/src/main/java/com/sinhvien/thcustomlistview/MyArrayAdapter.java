package com.sinhvien.thcustomlistview;

import android.app.Activity;
import android.provider.ContactsContract;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;

public class MyArrayAdapter extends ArrayAdapter<ContactsContract.CommonDataKinds.Phone> {
    Activity context;
    int idLayout;
    ArrayList<ContactsContract.CommonDataKinds.Phone> myList;

    public MyArrayAdapter(Activity context, int idLayout,ArrayList<ContactsContract.CommonDataKinds.Phone> myList){
        super(context,idLayout,myList);
        this.context = context;
        this.idLayout = idLayout;
        this.myList = myList;
    }

    @NotNull
    @Override
    public View getView(int position, @Nullable View convertView, @NotNull ViewGroup parent){
        //Tạo đế để chứa Layout
        LayoutInflater myInflater = context.getLayoutInflater();

        //Đặt id Layout lên đế để tạo thành View
        convertView = myInflater.inflate(idLayout,null);

        //Lấy từng phần tử trong danh sách myList để hiển thị lên
        ContactsContract.CommonDataKinds.Phone myPhone = myList.get(position);

        //Khai báo, tham chiếu id và hiển thị ảnh lên ImageView
        ImageView imgPhone = convertView.findViewById(R.id.imgPhone);
        

    }
}
